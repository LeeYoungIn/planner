package com.planner.value;

public class StringSet {

	public static final String DAY = "day";
	
	public static final String MODE = "mode";
	public static final String TODAY = "today";
	public static final String STARTDAY = "startday";
	public static final String MAIN = "Main";
	
}
